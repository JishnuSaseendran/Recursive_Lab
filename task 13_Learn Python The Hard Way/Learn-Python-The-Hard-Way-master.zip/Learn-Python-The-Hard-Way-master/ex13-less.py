from sys import argv

script, first_name, last_name = argv

print "Your full name is %s %s" % (first_name, last_name)