# 1. True
# 2. False
# 3. False
# 4. True
# 5. True
# 6. True
# 7. False
# 8. True
# 9. False
#10. False
#11. True
#12. False
#13. True
#14. False
#15. False
#16. False
#17. True
#18. True
#19. False
#20. False

# List of equality operators: <, >, ==, !=, <=, >=, is, is not
# less than, greater than, equal to, not equal to, less than or equal to, greater than or equal to, is, is not