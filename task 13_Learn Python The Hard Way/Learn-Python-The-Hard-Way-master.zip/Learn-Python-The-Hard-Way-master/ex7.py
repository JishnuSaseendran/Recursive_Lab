# prints the string
print "Mary had a little lamb."

# prints the string with the 'snow' inserted where the formatting character is
print "Its fleece was white as %s." % 'snow'

# prints the string
print "And everywhere that Mary went."

# prints 10 periods
print "." * 10 # what'd that do?

# sets end1 to "C"
end1 = "C"
# sets end2 to "h"
end2 = "h"
# sets end3 to "e"
end3 = "e"
# sets end4 to "e"
end4 = "e"
# sets end5 to "s"
end5 = "s"
# sets end6 to "e"
end6 = "e"
# sets end7 to "B"
end7 = "B"
# sets end8 to "u"
end8 = "u"
# sets end9 to "r"
end9 = "r"
# sets end10 to "g"
end10 = "g"
# sets end11 to "e"
end11 = "e"
# sets end12 to "r"
end12 = "r"

# watch that comma at the end. try removing it to see what happens
# prints the concatenation of end1 through end6 - the comma causing python to not add a line-break
print end1 + end2 + end3 + end4 + end5 + end6,
#
print end7 + end8 + end9 + end10 + end11 + end12