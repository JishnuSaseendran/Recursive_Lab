print "I will now count my chickens:"

# add 25 to (30 divided by 6)
print "Hens", 25 + 30 / 6

# subtract 100 by ((25 times 3) mod 4)
print "Roosters", 100 - 25 * 3 % 4

print "Now I will count the eggs:"

# 3 plus 2 plus 1 minus 5 plus (4 mod 2) minus (1 divided by 4) plus six
#                                  0                  0
print 3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6

print "Is it true that 3 + 2 < 5 - 7?"

# test if 5 < -2
print 3 + 2 < 5 - 7

# add 3 plus 2
print "What is 3 + 2?", 3 + 2

# subtract 7 from 5
print "What is 5 - 7?", 5 - 7

print "Oh, that's why it's False."

print "How about some more."

# test if 5 is greater than -2
print "Is it greater?", 5 > -2

# test if 5 is greater or equay to -2
print "Is it greater or equal?", 5 >= -2

# test if 5 is less than or equal to -2
print "Is it less or equal?", 5 <= -2