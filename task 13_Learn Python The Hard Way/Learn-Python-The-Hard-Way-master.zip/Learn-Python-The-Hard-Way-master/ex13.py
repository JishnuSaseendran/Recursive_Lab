from sys import argv

script, first, second, third = argv

print "The script is called:", script
print "The first variable is:", first
print "The second variable is:", second
print "Your third variable is:", third

# Extra credit
# 1. Error: ValueError: need more than 2 values to unpack
# This means that the script needs the correct amount of arguments (3) to process correctly