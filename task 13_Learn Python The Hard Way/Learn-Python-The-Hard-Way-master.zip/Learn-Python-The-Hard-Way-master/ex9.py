# Here's some new strange stuff, remember type it exactly.

# Set a variable called days to a string with shortened day names
days = "Mon Tue Wed Thu Fri Sat Sun"

# Set a variable called months to a string with shortened month names, separated by \n (newline) characters
months = "Jan\nFeb\nMar\nApr\nMay\nJun\nJul\nAug"

# print a string, along with days
print "Here's the days: ", days

# print a string, along with months
print "Here's the months: ", months

# print a long string with line breaks
print """
There's somethings going on here.
With the three double-quotes.
We'll be able to type as much as we like.
"""