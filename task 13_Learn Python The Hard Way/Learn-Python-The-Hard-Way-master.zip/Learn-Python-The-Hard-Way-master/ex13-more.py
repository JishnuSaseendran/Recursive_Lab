from sys import argv

script, num1, num2, num3, num4 = argv

print "The four numbers you entered are: %s, %s, %s and %s" % (num1, num2, num3, num4)